"""
Approach 1: Pure Cypher cycle detection on Neo4j.

This script implements the Cypher-only strategy described in
Cycle_Detection_Neo4j_Strategies.md:
- 3-node directed transfer cycles (triangles)
- 4-node directed cycles
- 5-node directed cycles

Output is printed as a research-friendly summary plus JSON so the result can be
copied directly into notes/reports.

Example:
    python src/cycle_detection/cypher_cycle_detection.py \
        --uri bolt://localhost:7687 --user neo4j --password password --limit 100

Environment variables are also supported:
    NEO4J_URI, NEO4J_USER, NEO4J_PASSWORD
"""

from __future__ import annotations

import argparse
import json
import os
import time
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Optional

from neo4j import GraphDatabase

try:
    from src.cycle_detection.result_io import save_cycle_records_jsonl
except ModuleNotFoundError:  # Allows direct execution from src/cycle_detection
    from result_io import save_cycle_records_jsonl


DEFAULT_URI = os.getenv("NEO4J_URI", "bolt://localhost:7687")
DEFAULT_USER = os.getenv("NEO4J_USER", "neo4j")
DEFAULT_PASSWORD = os.getenv("NEO4J_PASSWORD", "password")


@dataclass(frozen=True)
class QuerySpec:
    name: str
    description: str
    cypher: str


class CypherCycleDetector:
    """Detect transfer cycles using only Cypher queries."""

    TRIANGLE_QUERY = """
    MATCH (a:Account)-[:SENT]->(t1:Transaction)-[:RECEIVED_BY]->(b:Account),
          (b)-[:SENT]->(t2:Transaction)-[:RECEIVED_BY]->(c:Account),
          (c)-[:SENT]->(t3:Transaction)-[:RECEIVED_BY]->(a)
    WHERE a.account_id < b.account_id AND b.account_id < c.account_id
    RETURN DISTINCT
      [a.account_id, b.account_id, c.account_id] AS participants,
      3 AS cycle_size,
      coalesce(t1.amount_usd, t1.amount, 0) + coalesce(t2.amount_usd, t2.amount, 0) + coalesce(t3.amount_usd, t3.amount, 0) AS total_amount,
      (coalesce(a.kyc_risk_score, 0.5) + coalesce(b.kyc_risk_score, 0.5) + coalesce(c.kyc_risk_score, 0.5)) / 3.0 AS avg_kyc_risk_score,
      [toString(t1.timestamp), toString(t2.timestamp), toString(t3.timestamp)] AS timestamps
    ORDER BY total_amount DESC
    LIMIT $limit
    """

    UNION_FIXED_LENGTH_QUERY = """
    CALL {
      // 3-node account cycles via (:Account)-[:SENT]->(:Transaction)-[:RECEIVED_BY]->(:Account)
      MATCH (a:Account)-[:SENT]->(t1:Transaction)-[:RECEIVED_BY]->(b:Account),
            (b)-[:SENT]->(t2:Transaction)-[:RECEIVED_BY]->(c:Account),
            (c)-[:SENT]->(t3:Transaction)-[:RECEIVED_BY]->(a)
      WHERE a.account_id < b.account_id AND b.account_id < c.account_id
      RETURN DISTINCT
        [a.account_id, b.account_id, c.account_id] AS participants,
        3 AS cycle_size,
        coalesce(t1.amount_usd, t1.amount, 0) + coalesce(t2.amount_usd, t2.amount, 0) + coalesce(t3.amount_usd, t3.amount, 0) AS total_amount,
        (coalesce(a.kyc_risk_score, 0.5) + coalesce(b.kyc_risk_score, 0.5) + coalesce(c.kyc_risk_score, 0.5)) / 3.0 AS avg_kyc_risk_score

      UNION

      // 4-node account cycles
      MATCH (a:Account)-[:SENT]->(t1:Transaction)-[:RECEIVED_BY]->(b:Account),
            (b)-[:SENT]->(t2:Transaction)-[:RECEIVED_BY]->(c:Account),
            (c)-[:SENT]->(t3:Transaction)-[:RECEIVED_BY]->(d:Account),
            (d)-[:SENT]->(t4:Transaction)-[:RECEIVED_BY]->(a)
      WHERE a.account_id < b.account_id
        AND b.account_id < c.account_id
        AND c.account_id < d.account_id
      RETURN DISTINCT
        [a.account_id, b.account_id, c.account_id, d.account_id] AS participants,
        4 AS cycle_size,
        coalesce(t1.amount_usd, t1.amount, 0) + coalesce(t2.amount_usd, t2.amount, 0) + coalesce(t3.amount_usd, t3.amount, 0) + coalesce(t4.amount_usd, t4.amount, 0) AS total_amount,
        (coalesce(a.kyc_risk_score, 0.5) + coalesce(b.kyc_risk_score, 0.5) + coalesce(c.kyc_risk_score, 0.5) + coalesce(d.kyc_risk_score, 0.5)) / 4.0 AS avg_kyc_risk_score

      UNION

      // 5-node account cycles
      MATCH (a:Account)-[:SENT]->(t1:Transaction)-[:RECEIVED_BY]->(b:Account),
            (b)-[:SENT]->(t2:Transaction)-[:RECEIVED_BY]->(c:Account),
            (c)-[:SENT]->(t3:Transaction)-[:RECEIVED_BY]->(d:Account),
            (d)-[:SENT]->(t4:Transaction)-[:RECEIVED_BY]->(e:Account),
            (e)-[:SENT]->(t5:Transaction)-[:RECEIVED_BY]->(a)
      WHERE a.account_id < b.account_id
        AND b.account_id < c.account_id
        AND c.account_id < d.account_id
        AND d.account_id < e.account_id
      RETURN DISTINCT
        [a.account_id, b.account_id, c.account_id, d.account_id, e.account_id] AS participants,
        5 AS cycle_size,
        coalesce(t1.amount_usd, t1.amount, 0) + coalesce(t2.amount_usd, t2.amount, 0) + coalesce(t3.amount_usd, t3.amount, 0) + coalesce(t4.amount_usd, t4.amount, 0) + coalesce(t5.amount_usd, t5.amount, 0) AS total_amount,
        (coalesce(a.kyc_risk_score, 0.5) + coalesce(b.kyc_risk_score, 0.5) + coalesce(c.kyc_risk_score, 0.5) + coalesce(d.kyc_risk_score, 0.5) + coalesce(e.kyc_risk_score, 0.5)) / 5.0 AS avg_kyc_risk_score
    }
    RETURN participants, cycle_size, total_amount, avg_kyc_risk_score
    ORDER BY cycle_size DESC, total_amount DESC
    LIMIT $limit
    """

    CYCLE_4_QUERY = """
    MATCH (a:Account)-[:SENT]->(t1:Transaction)-[:RECEIVED_BY]->(b:Account),
          (b)-[:SENT]->(t2:Transaction)-[:RECEIVED_BY]->(c:Account),
          (c)-[:SENT]->(t3:Transaction)-[:RECEIVED_BY]->(d:Account),
          (d)-[:SENT]->(t4:Transaction)-[:RECEIVED_BY]->(a)
    WHERE a.account_id < b.account_id
      AND b.account_id < c.account_id
      AND c.account_id < d.account_id
    RETURN DISTINCT
      [a.account_id, b.account_id, c.account_id, d.account_id] AS participants,
      4 AS cycle_size,
      coalesce(t1.amount_usd, t1.amount, 0) + coalesce(t2.amount_usd, t2.amount, 0) + coalesce(t3.amount_usd, t3.amount, 0) + coalesce(t4.amount_usd, t4.amount, 0) AS total_amount,
      (coalesce(a.kyc_risk_score, 0.5) + coalesce(b.kyc_risk_score, 0.5) + coalesce(c.kyc_risk_score, 0.5) + coalesce(d.kyc_risk_score, 0.5)) / 4.0 AS avg_kyc_risk_score
    ORDER BY total_amount DESC
    LIMIT $limit
    """

    CYCLE_5_QUERY = """
    MATCH (a:Account)-[:SENT]->(t1:Transaction)-[:RECEIVED_BY]->(b:Account),
          (b)-[:SENT]->(t2:Transaction)-[:RECEIVED_BY]->(c:Account),
          (c)-[:SENT]->(t3:Transaction)-[:RECEIVED_BY]->(d:Account),
          (d)-[:SENT]->(t4:Transaction)-[:RECEIVED_BY]->(e:Account),
          (e)-[:SENT]->(t5:Transaction)-[:RECEIVED_BY]->(a)
    WHERE a.account_id < b.account_id
      AND b.account_id < c.account_id
      AND c.account_id < d.account_id
      AND d.account_id < e.account_id
    RETURN DISTINCT
      [a.account_id, b.account_id, c.account_id, d.account_id, e.account_id] AS participants,
      5 AS cycle_size,
      coalesce(t1.amount_usd, t1.amount, 0) + coalesce(t2.amount_usd, t2.amount, 0) + coalesce(t3.amount_usd, t3.amount, 0) + coalesce(t4.amount_usd, t4.amount, 0) + coalesce(t5.amount_usd, t5.amount, 0) AS total_amount,
      (coalesce(a.kyc_risk_score, 0.5) + coalesce(b.kyc_risk_score, 0.5) + coalesce(c.kyc_risk_score, 0.5) + coalesce(d.kyc_risk_score, 0.5) + coalesce(e.kyc_risk_score, 0.5)) / 5.0 AS avg_kyc_risk_score
    ORDER BY total_amount DESC
    LIMIT $limit
    """

    FIXED_LENGTH_QUERIES = {
        3: TRIANGLE_QUERY,
        4: CYCLE_4_QUERY,
        5: CYCLE_5_QUERY,
    }

    VARIABLE_LENGTH_QUERY = """
    MATCH path = (start:Account)-[:SENT|RECEIVED_BY*6..16]->(start)
    WHERE length(path) % 2 = 0
      AND all(i IN range(0, length(path) - 1) WHERE
        (i % 2 = 0 AND type(relationships(path)[i]) = 'SENT') OR
        (i % 2 = 1 AND type(relationships(path)[i]) = 'RECEIVED_BY')
      )
    WITH [n IN nodes(path) WHERE n:Account | n.account_id] AS participants,
         [n IN nodes(path) WHERE n:Account | n] AS account_nodes,
         [n IN nodes(path) WHERE n:Transaction | n] AS tx_nodes,
         length(path) / 2 AS cycle_size
    WHERE cycle_size >= 3 AND cycle_size <= 8
      AND size(apoc.coll.toSet(participants[0..cycle_size])) = cycle_size
    RETURN participants[0..cycle_size] AS participants,
           cycle_size,
           reduce(total = 0, t IN tx_nodes | total + coalesce(t.amount_usd, t.amount, 0)) AS total_amount,
           reduce(risk_total = 0.0, account_id IN participants[0..cycle_size] |
             risk_total + coalesce(head([n IN account_nodes WHERE n.account_id = account_id | n.kyc_risk_score]), 0.5)
           ) / cycle_size AS avg_kyc_risk_score
    ORDER BY cycle_size DESC, total_amount DESC
    LIMIT $limit
    """

    def __init__(
        self,
        uri: str = DEFAULT_URI,
        user: str = DEFAULT_USER,
        password: str = DEFAULT_PASSWORD,
        driver: Any = None,
    ) -> None:
        self.driver = driver or GraphDatabase.driver(uri, auth=(user, password))
        self.last_results: List[Dict[str, Any]] = []

    def close(self) -> None:
        if self.driver is not None:
            self.driver.close()

    def get_graph_stats(self) -> Dict[str, int]:
        with self.driver.session() as session:
            record = session.run(
                """
                MATCH (a:Account)
                WITH count(a) AS nodes
                OPTIONAL MATCH (:Account)-[:SENT]->(t:Transaction)-[:RECEIVED_BY]->(:Account)
                RETURN nodes, count(t) AS edges
                """
            ).single()
        if record is None:
            return {"nodes": 0, "edges": 0}
        return {"nodes": int(record["nodes"] or 0), "edges": int(record["edges"] or 0)}

    def find_triangles(self, limit: int = 100) -> List[Dict[str, Any]]:
        return self._run_query(self.TRIANGLE_QUERY, limit)

    def find_fixed_length_cycles(self, limit: int = 500) -> List[Dict[str, Any]]:
        """Run 3-, 4-, and 5-account cycle queries independently.

        The old UNION query sorted by cycle_size DESC before applying LIMIT,
        so when many 5-account cycles existed the final output contained only
        participant_count=5. Running a bounded query per size prevents that
        size-5 limit bias and keeps smaller rings visible.
        """
        results: List[Dict[str, Any]] = []
        for cycle_size in sorted(self.FIXED_LENGTH_QUERIES):
            size_results = self._run_query(self.FIXED_LENGTH_QUERIES[cycle_size], limit)
            for item in size_results:
                item["candidate_cycle_size"] = cycle_size
            results.extend(size_results)
        results.sort(key=lambda item: (item.get("cycle_size", 0), item.get("total_amount", 0)), reverse=True)
        return results

    def find_variable_length_cycles_apoc(self, limit: int = 1000) -> List[Dict[str, Any]]:
        """Run variable length query. Requires APOC because it uses apoc.coll.toSet."""
        return self._run_query(self.VARIABLE_LENGTH_QUERY, limit)

    def _run_query(self, query: str, limit: int) -> List[Dict[str, Any]]:
        with self.driver.session() as session:
            result = session.run(query, limit=limit)
            return [self._normalize_record(dict(record)) for record in result]

    @staticmethod
    def _normalize_record(record: Dict[str, Any]) -> Dict[str, Any]:
        normalized = dict(record)
        if "total_amount" in normalized and normalized["total_amount"] is not None:
            normalized["total_amount"] = float(normalized["total_amount"])
        return normalized

    def add_group_metrics_to_cycle_records(self, records: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Add exact account-group transaction metrics for JSONL aggregation.

        A Cypher cycle row represents one transaction-path combination. If the
        same participant set has many parallel transactions, summing every path
        combination inflates transaction_count and total_amount. These group
        metrics count distinct Transaction nodes inside the participant set once.
        """
        if not records:
            return records

        cache: Dict[tuple, Dict[str, Any]] = {}
        with self.driver.session() as session:
            for record in records:
                participants = tuple(sorted(str(item) for item in (record.get("participants") or []) if item is not None))
                if not participants:
                    continue
                if participants not in cache:
                    metrics = session.run(
                        """
                        MATCH (account:Account)
                        WHERE account.account_id IN $participants
                        WITH collect(account) AS accounts
                        OPTIONAL MATCH (src:Account)-[:SENT]->(t:Transaction)-[:RECEIVED_BY]->(dst:Account)
                        WHERE src.account_id IN $participants
                          AND dst.account_id IN $participants
                        WITH accounts, collect(DISTINCT t) AS txs
                        RETURN size(txs) AS transactions,
                               reduce(total = 0.0, tx IN txs | total + coalesce(tx.amount_usd, tx.amount, 0)) AS total_amount,
                               reduce(risk_total = 0.0, account IN accounts | risk_total + coalesce(account.kyc_risk_score, 0.5)) / size(accounts) AS avg_source_risk
                        """,
                        participants=list(participants),
                    ).single()
                    cache[participants] = {
                        "group_transactions": int(metrics["transactions"] or 0) if metrics else 0,
                        "group_total_amount": float(metrics["total_amount"] or 0.0) if metrics else 0.0,
                        "avg_kyc_risk_score": float(metrics["avg_source_risk"] or 0.5) if metrics else record.get("avg_kyc_risk_score", 0.5),
                    }
                record.update(cache[participants])
                record["metrics_are_group_level"] = True
        return records

    @staticmethod
    def build_research_summary(
        approach: str,
        graph_stats: Dict[str, Any],
        result_count: int,
        elapsed_ms: float,
        sample_results: Iterable[Dict[str, Any]],
        notes: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        return {
            "approach": approach,
            "graph_stats": graph_stats,
            "result_count": result_count,
            "elapsed_ms": round(elapsed_ms, 3),
            "sample_results": list(sample_results),
            "notes": notes or [],
        }

    def run(self, mode: str = "fixed", limit: int = 500) -> Dict[str, Any]:
        start = time.perf_counter()
        graph_stats = self.get_graph_stats()

        if mode == "triangles":
            results = self.find_triangles(limit=limit)
            notes = ["Pure Cypher directed 3-node cycle query."]
        elif mode == "variable":
            results = self.find_variable_length_cycles_apoc(limit=limit)
            notes = [
                "Variable-length 3..8 cycles.",
                "Requires APOC and can be slow on large graphs; use for exploration only.",
            ]
        else:
            results = self.find_fixed_length_cycles(limit=limit)
            notes = [
                "Recommended Cypher mode from markdown: UNION of explicit 3/4/5-node patterns.",
                "Ordering constraints reduce duplicate cycles and keep performance predictable.",
            ]

        self.last_results = self.add_group_metrics_to_cycle_records(results)
        elapsed_ms = (time.perf_counter() - start) * 1000
        return self.build_research_summary(
            approach=f"pure_cypher_{mode}",
            graph_stats=graph_stats,
            result_count=len(results),
            elapsed_ms=elapsed_ms,
            sample_results=results[:10],
            notes=notes,
        )

    @staticmethod
    def dry_run_queries() -> List[QuerySpec]:
        specs = [QuerySpec("triangles", "3-node directed cycles", CypherCycleDetector.TRIANGLE_QUERY)]
        specs.extend(
            QuerySpec(f"fixed_{size}", f"{size}-node directed cycles used by fixed mode", query)
            for size, query in CypherCycleDetector.FIXED_LENGTH_QUERIES.items()
        )
        specs.append(QuerySpec("variable", "APOC-assisted variable length cycles 3..8", CypherCycleDetector.VARIABLE_LENGTH_QUERY))
        return specs


def print_research_output(summary: Dict[str, Any]) -> None:
    print("=" * 78)
    print("APPROACH 1 - PURE CYPHER CYCLE DETECTION")
    print("=" * 78)
    print(f"Approach        : {summary['approach']}")
    print(f"Nodes / Edges   : {summary['graph_stats'].get('nodes', 0)} / {summary['graph_stats'].get('edges', 0)}")
    print(f"Cycles returned : {summary['result_count']}")
    print(f"Runtime         : {summary['elapsed_ms']} ms")
    print("Notes:")
    for note in summary.get("notes", []):
        print(f"  - {note}")
    print("\nTop sample results:")
    for idx, item in enumerate(summary.get("sample_results", []), start=1):
        print(f"  {idx:02d}. size={item.get('cycle_size')} amount={item.get('total_amount')} participants={item.get('participants')}")
    print("\nJSON_RESULT:")
    print(json.dumps(summary, ensure_ascii=False, indent=2, default=str))


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Pure Cypher cycle detection for Neo4j Account/TRANSFER graph")
    parser.add_argument("--uri", default=DEFAULT_URI, help="Neo4j Bolt URI")
    parser.add_argument("--user", default=DEFAULT_USER, help="Neo4j username")
    parser.add_argument("--password", default=DEFAULT_PASSWORD, help="Neo4j password")
    parser.add_argument("--mode", choices=["fixed", "triangles", "variable"], default="fixed")
    parser.add_argument("--limit", type=int, default=500)
    parser.add_argument("--json-out", default=None, help="Optional path to save summary JSON")
    parser.add_argument(
        "--jsonl-out",
        default=None,
        help="Optional path to save full detected fraud rings as JSONL, one ground-truth-like ring per line",
    )
    parser.add_argument("--min-fraud-score", type=float, default=0.35, help="Minimum heuristic fraud score for JSONL fraud-ring output")
    parser.add_argument("--include-non-fraud", action="store_true", help="Include benign cycle rings in JSONL instead of filtering to fraud only")
    parser.add_argument("--dry-run", action="store_true", help="Print Cypher queries without connecting to Neo4j")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.dry_run:
        for spec in CypherCycleDetector.dry_run_queries():
            print(f"\n--- {spec.name}: {spec.description} ---")
            print(spec.cypher.strip())
        return

    detector = CypherCycleDetector(args.uri, args.user, args.password)
    try:
        summary = detector.run(mode=args.mode, limit=args.limit)
        print_research_output(summary)
        if args.json_out:
            with open(args.json_out, "w", encoding="utf-8") as f:
                json.dump(summary, f, ensure_ascii=False, indent=2, default=str)
            print(f"\nSaved JSON summary to: {args.json_out}")
        if args.jsonl_out:
            rings = save_cycle_records_jsonl(
                args.jsonl_out,
                detector.last_results,
                ring_id_prefix="RING",
                ring_type="detected_cycle",
                source_approach=summary["approach"],
                include_instances=False,
                fraud_only=not args.include_non_fraud,
                min_fraud_score=args.min_fraud_score,
            )
            mode = "fraud-ring" if not args.include_non_fraud else "cycle/ring"
            print(f"Saved {len(rings)} {mode} records to JSONL: {args.jsonl_out}")
    finally:
        detector.close()


if __name__ == "__main__":
    main()
