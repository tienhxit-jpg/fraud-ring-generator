"""
Approach 3: Hybrid Neo4j pull + Python NetworkX cycle detection.

This script implements the Hybrid strategy from Cycle_Detection_Neo4j_Strategies.md:
- Pull Account nodes and TRANSFER relationships from Neo4j
- Build a NetworkX directed graph locally
- Enumerate simple cycles with an explicit length limit
- Score cycles using size, amount, participant risk, density, and activity
- Optionally persist top results back to Neo4j as FraudRing nodes

Example:
    python src/cycle_detection/hybrid_networkx_cycle_detection.py \
        --uri bolt://localhost:7687 --user neo4j --password password \
        --max-cycle-length 10 --limit 100 --save
"""

from __future__ import annotations

import argparse
import json
import math
import os
import time
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import networkx as nx
from neo4j import GraphDatabase

try:
    from src.cycle_detection.result_io import save_cycle_records_jsonl
except ModuleNotFoundError:  # Allows direct execution from src/cycle_detection
    from result_io import save_cycle_records_jsonl


DEFAULT_URI = os.getenv("NEO4J_URI", "bolt://localhost:7687")
DEFAULT_USER = os.getenv("NEO4J_USER", "neo4j")
DEFAULT_PASSWORD = os.getenv("NEO4J_PASSWORD", "password")


class HybridNetworkXCycleDetector:
    """Load Neo4j graph into NetworkX and perform flexible local analysis."""

    def __init__(
        self,
        uri: str = DEFAULT_URI,
        user: str = DEFAULT_USER,
        password: str = DEFAULT_PASSWORD,
        driver: Any = None,
    ) -> None:
        self.driver = driver if driver is not None else GraphDatabase.driver(uri, auth=(user, password))
        self.last_results: List[Dict[str, Any]] = []

    def close(self) -> None:
        if self.driver is not None:
            self.driver.close()

    def load_graph_from_neo4j(self) -> nx.DiGraph:
        if self.driver is None:
            raise RuntimeError("Neo4j driver is required to load graph data")

        graph = nx.DiGraph()
        with self.driver.session() as session:
            node_result = session.run(
                """
                MATCH (a:Account)
                RETURN a.account_id AS account_id,
                       coalesce(a.kyc_risk_score, 0.5) AS risk_score,
                       coalesce(a.monthly_transaction_count, 0) AS monthly_transaction_count
                """
            )
            for record in node_result:
                graph.add_node(
                    record["account_id"],
                    risk_score=float(record["risk_score"] or 0.5),
                    monthly_transaction_count=float(record["monthly_transaction_count"] or 0),
                )

            edge_result = session.run(
                """
                MATCH (a:Account)-[:SENT]->(t:Transaction)-[:RECEIVED_BY]->(b:Account)
                RETURN a.account_id AS source,
                       b.account_id AS destination,
                       coalesce(t.amount_usd, t.amount, 0) AS amount,
                       toString(t.timestamp) AS timestamp
                """
            )
            for record in edge_result:
                amount = float(record["amount"] or 0)
                source = record["source"]
                destination = record["destination"]
                if graph.has_edge(source, destination):
                    graph[source][destination]["weight"] += amount
                    graph[source][destination]["amount"] += amount
                    graph[source][destination]["transaction_count"] += 1
                else:
                    graph.add_edge(
                        source,
                        destination,
                        weight=amount,
                        amount=amount,
                        timestamp=record["timestamp"],
                        transaction_count=1,
                    )

        return graph

    def detect_cycles(
        self,
        graph: nx.DiGraph,
        max_cycle_length: int = 10,
        limit: int = 500,
    ) -> List[Dict[str, Any]]:
        """Find, score, sort, and limit simple directed cycles."""
        raw_cycles = nx.simple_cycles(graph, length_bound=max_cycle_length)
        scored: List[Dict[str, Any]] = []
        for cycle in raw_cycles:
            if len(cycle) < 2:
                continue
            scored.append(self.describe_cycle(graph, cycle))

        scored.sort(key=lambda item: (item["score"], item["total_amount"], item["cycle_size"]), reverse=True)
        return scored[:limit]

    def describe_cycle(self, graph: nx.DiGraph, cycle: Sequence[str]) -> Dict[str, Any]:
        total_amount = self.get_cycle_amount(graph, cycle)
        density = self.calculate_cycle_density(graph, cycle)
        risk_values = [self._safe_float(graph.nodes[node].get("risk_score", 0.5), 0.5) for node in cycle]
        activity_values = [self._safe_float(graph.nodes[node].get("monthly_transaction_count", 0), 0) for node in cycle]
        avg_risk = sum(risk_values) / len(risk_values) if risk_values else 0.5
        avg_activity = sum(activity_values) / len(activity_values) if activity_values else 0.0
        score = self.score_cycle(graph, cycle)

        return {
            "participants": list(cycle),
            "cycle_size": len(cycle),
            "transactions": self.get_cycle_transaction_count(graph, cycle),
            "total_amount": round(total_amount, 3),
            "avg_kyc_risk_score": round(avg_risk, 4),
            "avg_monthly_transaction_count": round(avg_activity, 3),
            "density": round(density, 4),
            "score": round(score, 4),
            "method": "hybrid_networkx_simple_cycles",
        }

    def score_cycle(self, graph: nx.DiGraph, cycle: Sequence[str]) -> float:
        """
        Score fraud likelihood in [0, 1].

        Higher values mean the cycle is more suspicious. The formula follows the
        markdown idea and keeps every factor bounded so the result is stable for
        research comparison:
        - size factor: larger rings up to 10 nodes
        - amount factor: saturates at 100,000
        - risk factor: low KYC score is interpreted as higher risk, matching the
          source markdown's inverted risk example
        - density factor: extra internal transfers among participants
        - activity factor: saturates at 100 monthly transactions
        """
        if not cycle:
            return 0.0

        total_amount = self.get_cycle_amount(graph, cycle)
        density = self.calculate_cycle_density(graph, cycle)
        avg_risk = self._average(graph.nodes[node].get("risk_score", 0.5) for node in cycle)
        avg_activity = self._average(graph.nodes[node].get("monthly_transaction_count", 0) for node in cycle)

        size_factor = min(len(cycle) / 10.0, 1.0)
        amount_factor = min(total_amount / 100000.0, 1.0)
        inverted_risk_factor = max(0.0, min(1.0, 1.0 - avg_risk))
        activity_factor = min(avg_activity / 100.0, 1.0)

        score = (
            size_factor * 0.20
            + amount_factor * 0.30
            + inverted_risk_factor * 0.20
            + density * 0.20
            + activity_factor * 0.10
        )
        return max(0.0, min(score, 1.0))

    def get_cycle_amount(self, graph: nx.DiGraph, cycle: Sequence[str]) -> float:
        total = 0.0
        for source, destination in self._cycle_edges(cycle):
            if graph.has_edge(source, destination):
                total += self._safe_float(graph[source][destination].get("weight", 0), 0.0)
        return total

    def get_cycle_transaction_count(self, graph: nx.DiGraph, cycle: Sequence[str]) -> int:
        total = 0
        for source, destination in self._cycle_edges(cycle):
            if graph.has_edge(source, destination):
                total += int(graph[source][destination].get("transaction_count", 1))
        return total

    def calculate_cycle_density(self, graph: nx.DiGraph, cycle: Sequence[str]) -> float:
        if len(cycle) <= 1:
            return 0.0
        subgraph = graph.subgraph(cycle)
        max_edges = len(cycle) * (len(cycle) - 1)
        return subgraph.number_of_edges() / max_edges if max_edges else 0.0

    def save_results_to_neo4j(self, cycles: Sequence[Dict[str, Any]], max_save: int = 500) -> int:
        if self.driver is None:
            raise RuntimeError("Neo4j driver is required to save results")

        saved = 0
        with self.driver.session() as session:
            for index, cycle_info in enumerate(cycles[:max_save]):
                ring_id = f"HYBRID_RING_{index:04d}"
                participants = list(cycle_info["participants"])
                session.run(
                    """
                    MERGE (ring:FraudRing {ring_id: $ring_id})
                    SET ring.method = 'hybrid_networkx',
                        ring.score = $score,
                        ring.size = $size,
                        ring.amount = $amount,
                        ring.density = $density,
                        ring.detected_at = datetime()
                    """,
                    ring_id=ring_id,
                    score=float(cycle_info.get("score", 0)),
                    size=int(cycle_info.get("cycle_size", len(participants))),
                    amount=float(cycle_info.get("total_amount", 0)),
                    density=float(cycle_info.get("density", 0)),
                )
                session.run(
                    """
                    MATCH (ring:FraudRing {ring_id: $ring_id})
                    UNWIND range(0, size($participants) - 1) AS idx
                    MATCH (account:Account {account_id: $participants[idx]})
                    MERGE (account)-[member:MEMBER_OF]->(ring)
                    SET member.position = idx
                    """,
                    ring_id=ring_id,
                    participants=participants,
                )
                saved += 1
        return saved

    def run(
        self,
        max_cycle_length: int = 10,
        limit: int = 500,
        save: bool = False,
        max_save: int = 500,
    ) -> Dict[str, Any]:
        start = time.perf_counter()
        graph = self.load_graph_from_neo4j()
        load_elapsed_ms = (time.perf_counter() - start) * 1000

        detect_start = time.perf_counter()
        cycles = self.detect_cycles(graph, max_cycle_length=max_cycle_length, limit=limit)
        self.last_results = cycles
        detect_elapsed_ms = (time.perf_counter() - detect_start) * 1000

        saved_count = self.save_results_to_neo4j(cycles, max_save=max_save) if save else 0
        elapsed_ms = (time.perf_counter() - start) * 1000

        return self.build_research_summary(
            graph=graph,
            cycles=cycles,
            max_cycle_length=max_cycle_length,
            elapsed_ms=elapsed_ms,
            load_elapsed_ms=load_elapsed_ms,
            detect_elapsed_ms=detect_elapsed_ms,
            saved_count=saved_count,
        )

    @staticmethod
    def build_research_summary(
        graph: nx.DiGraph,
        cycles: Sequence[Dict[str, Any]],
        max_cycle_length: int,
        elapsed_ms: float,
        load_elapsed_ms: float,
        detect_elapsed_ms: float,
        saved_count: int = 0,
    ) -> Dict[str, Any]:
        return {
            "approach": "hybrid_neo4j_networkx",
            "graph_stats": {
                "nodes": graph.number_of_nodes(),
                "edges": graph.number_of_edges(),
                "density": round(nx.density(graph), 6) if graph.number_of_nodes() > 1 else 0,
            },
            "parameters": {"max_cycle_length": max_cycle_length},
            "result_count": len(cycles),
            "saved_to_neo4j_count": saved_count,
            "elapsed_ms": round(elapsed_ms, 3),
            "load_elapsed_ms": round(load_elapsed_ms, 3),
            "detect_elapsed_ms": round(detect_elapsed_ms, 3),
            "sample_results": list(cycles[:10]),
            "notes": [
                "NetworkX simple_cycles gives exact directed simple cycles within the selected length bound.",
                "This approach is most flexible but loads the graph into Python memory.",
                "Use --save to persist top cycles as FraudRing nodes with MEMBER_OF relationships.",
            ],
        }

    @staticmethod
    def _cycle_edges(cycle: Sequence[str]) -> Iterable[Tuple[str, str]]:
        for index, source in enumerate(cycle):
            yield source, cycle[(index + 1) % len(cycle)]

    @staticmethod
    def _safe_float(value: Any, default: float) -> float:
        try:
            result = float(value)
            return default if math.isnan(result) else result
        except (TypeError, ValueError):
            return default

    @classmethod
    def _average(cls, values: Iterable[Any]) -> float:
        cleaned = [cls._safe_float(value, 0.0) for value in values]
        return sum(cleaned) / len(cleaned) if cleaned else 0.0


def print_research_output(summary: Dict[str, Any]) -> None:
    print("=" * 78)
    print("APPROACH 3 - HYBRID NEO4J + PYTHON NETWORKX")
    print("=" * 78)
    print(f"Nodes / Edges       : {summary['graph_stats'].get('nodes', 0)} / {summary['graph_stats'].get('edges', 0)}")
    print(f"Graph density       : {summary['graph_stats'].get('density', 0)}")
    print(f"Max cycle length    : {summary['parameters'].get('max_cycle_length')}")
    print(f"Cycles returned     : {summary['result_count']}")
    print(f"Saved to Neo4j      : {summary['saved_to_neo4j_count']}")
    print(f"Load runtime        : {summary['load_elapsed_ms']} ms")
    print(f"Detection runtime   : {summary['detect_elapsed_ms']} ms")
    print(f"Total runtime       : {summary['elapsed_ms']} ms")
    print("\nTop scored cycles:")
    for idx, item in enumerate(summary.get("sample_results", []), start=1):
        print(
            f"  {idx:02d}. score={item.get('score')} size={item.get('cycle_size')} "
            f"amount={item.get('total_amount')} density={item.get('density')} "
            f"participants={item.get('participants')}"
        )
    print("\nJSON_RESULT:")
    print(json.dumps(summary, ensure_ascii=False, indent=2, default=str))


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Hybrid Neo4j + NetworkX cycle detection for Account/TRANSFER graph")
    parser.add_argument("--uri", default=DEFAULT_URI, help="Neo4j Bolt URI")
    parser.add_argument("--user", default=DEFAULT_USER, help="Neo4j username")
    parser.add_argument("--password", default=DEFAULT_PASSWORD, help="Neo4j password")
    parser.add_argument("--max-cycle-length", type=int, default=10, help="Bound for NetworkX simple cycle enumeration")
    parser.add_argument("--limit", type=int, default=500, help="Maximum scored cycles to return")
    parser.add_argument("--save", action="store_true", help="Persist detected rings to Neo4j as FraudRing nodes")
    parser.add_argument("--max-save", type=int, default=500, help="Maximum rings to save when --save is enabled")
    parser.add_argument("--json-out", default=None, help="Optional path to save summary JSON")
    parser.add_argument(
        "--jsonl-out",
        default=None,
        help="Optional path to save full detected fraud rings as JSONL, one ground-truth-like ring per line",
    )
    parser.add_argument("--min-fraud-score", type=float, default=0.35, help="Minimum heuristic fraud score for JSONL fraud-ring output")
    parser.add_argument("--include-non-fraud", action="store_true", help="Include benign cycle rings in JSONL instead of filtering to fraud only")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    detector = HybridNetworkXCycleDetector(args.uri, args.user, args.password)
    try:
        summary = detector.run(
            max_cycle_length=args.max_cycle_length,
            limit=args.limit,
            save=args.save,
            max_save=args.max_save,
        )
        print_research_output(summary)
        if args.json_out:
            with open(args.json_out, "w", encoding="utf-8") as f:
                json.dump(summary, f, ensure_ascii=False, indent=2, default=str)
            print(f"\nSaved JSON summary to: {args.json_out}")
        if args.jsonl_out:
            rings = save_cycle_records_jsonl(
                args.jsonl_out,
                detector.last_results,
                ring_id_prefix="RING",
                ring_type="detected_cycle",
                source_approach=summary["approach"],
                include_instances=False,
                fraud_only=not args.include_non_fraud,
                min_fraud_score=args.min_fraud_score,
            )
            mode = "fraud-ring" if not args.include_non_fraud else "cycle/ring"
            print(f"Saved {len(rings)} {mode} records to JSONL: {args.jsonl_out}")
    finally:
        detector.close()


if __name__ == "__main__":
    main()
