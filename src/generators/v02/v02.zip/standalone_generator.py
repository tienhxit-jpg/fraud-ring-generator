#!/usr/bin/env python3
"""
Standalone Synthetic Data Generator for Fraud Ring Detection
Generates realistic synthetic data for academic research on fraud detection in digital banking.
"""

import json
import csv
import os
import random
from datetime import datetime, timedelta
from collections import defaultdict

# Configuration
CONFIG = {
    "total_transactions": 50000,
    "normal_transaction_ratio": 0.95,
    "fraud_transaction_ratio": 0.05,
    "normal_account_count": 5000,
    "merchant_count": 200,
    "total_ring_count": 45,
    "small_rings": 15,
    "medium_rings": 20,
    "large_rings": 10,
    "start_date": "2025-10-01",
    "end_date": "2025-12-31",
    "seed": 42
}

# Set seed for reproducibility
random.seed(CONFIG["seed"])

# Create output directories
os.makedirs("data/synthetic/raw", exist_ok=True)
os.makedirs("data/synthetic/ground_truth", exist_ok=True)

def generate_accounts():
    """Generate normal customer accounts"""
    print(f"Generating {CONFIG['normal_account_count']} normal accounts...")
    
    accounts = []
    start_date = datetime.strptime(CONFIG["start_date"], "%Y-%m-%d")
    end_date = datetime.strptime(CONFIG["end_date"], "%Y-%m-%d")
    
    for i in range(CONFIG["normal_account_count"]):
        account_id = f"ACC_{i+1:06d}"
        
        # Account age (in days)
        account_age = random.randint(30, 2000)
        created_date = end_date - timedelta(days=account_age)
        
        # KYC risk score (0-1, lower is better)
        kyc_risk = random.betavariate(2.0, 8.0)
        
        # Daily limit
        daily_limit = random.choice([10000, 25000, 50000, 100000])
        
        # Average transaction amount
        avg_amount = max(100, random.normalvariate(1500, 500))
        
        # Monthly transaction count
        monthly_txn = int(random.expovariate(1/40))
        
        accounts.append({
            'account_id': account_id,
            'customer_id': f"CUST_{i+1:06d}",
            'customer_name': f"Customer {i+1}",
            'account_type': random.choice(['checking', 'savings', 'business']),
            'created_date': created_date.strftime('%Y-%m-%d'),
            'account_age_days': account_age,
            'kyc_risk_score': round(kyc_risk, 3),
            'kyc_level': 'verified' if kyc_risk < 0.5 else 'pending',
            'daily_limit_usd': daily_limit,
            'avg_transaction_amount': round(avg_amount, 2),
            'monthly_transaction_count': monthly_txn,
            'is_blacklisted': False,
            'status': 'active'
        })
    
    return accounts

def generate_merchants():
    """Generate merchant accounts"""
    print(f"Generating {CONFIG['merchant_count']} merchants...")
    
    merchants = []
    categories = ['retail', 'online', 'restaurant', 'services', 'telecom', 'utilities']
    
    for i in range(CONFIG['merchant_count']):
        merchant_id = f"MER_{i+1:06d}"
        is_high_risk = i < 50  # First 50 are high risk
        
        merchants.append({
            'merchant_id': merchant_id,
            'merchant_name': f"Merchant {i+1}",
            'merchant_type': random.choice(['retail', 'online', 'bank']),
            'category': random.choice(categories),
            'risk_level': 'high' if is_high_risk else 'low',
            'is_verified': True,
            'country': 'Vietnam'
        })
    
    return merchants

def generate_fraud_rings(accounts):
    """Generate fraud rings with different sizes"""
    print(f"Generating {CONFIG['total_ring_count']} fraud rings...")
    
    fraud_rings = []
    fraud_transactions = []
    ring_id_counter = 0
    
    # Small rings (3 participants)
    for _ in range(CONFIG['small_rings']):
        participants = random.sample(accounts, 3)
        participant_ids = [acc['account_id'] for acc in participants]
        
        # Number of cycles
        num_cycles = random.randint(5, 10)
        base_amount = random.uniform(15000, 50000)
        
        ring_transactions = []
        ring_id = f'RING_{ring_id_counter:04d}'
        
        for cycle_num in range(num_cycles):
            # Escalating amounts
            amount = base_amount * (1 + 0.05 * cycle_num)
            amount_per_txn = amount / 3
            
            # Cycle start time
            cycle_start = datetime.strptime(CONFIG["start_date"], "%Y-%m-%d") + timedelta(
                days=random.randint(0, 85),
                hours=random.choice([8, 9, 10, 14, 15, 16])
            )
            
            # A → B → C → A
            for i in range(3):
                src = participant_ids[i]
                dst = participant_ids[(i + 1) % 3]
                
                timestamp = cycle_start + timedelta(hours=i*2)
                
                ring_transactions.append({
                    'source_account': src,
                    'destination_account': dst,
                    'amount': round(amount_per_txn, 2),
                    'timestamp': timestamp.strftime('%Y-%m-%d %H:%M:%S'),
                    'ring_id': ring_id,
                    'is_fraud': 1,
                    'cycle_num': cycle_num
                })
        
        fraud_transactions.extend(ring_transactions)
        
        fraud_rings.append({
            'ring_id': ring_id,
            'ring_type': random.choice(['money_laundering', 'account_takeover', 'collusion', 'phishing']),
            'participants': participant_ids,
            'participant_count': 3,
            'transactions': len(ring_transactions),
            'total_amount': round(sum(t['amount'] for t in ring_transactions), 2),
            'pattern': 'cycle_3',
            'cycles': num_cycles
        })
        
        print(f"  • Small ring {ring_id_counter}: {participant_ids} → ${round(sum(t['amount'] for t in ring_transactions), 2):,.0f}")
        ring_id_counter += 1
    
    # Medium rings (5 participants)
    for _ in range(CONFIG['medium_rings']):
        participants = random.sample(accounts, 5)
        participant_ids = [acc['account_id'] for acc in participants]
        
        num_cycles = random.randint(8, 15)
        base_amount = random.uniform(75000, 150000)
        
        ring_transactions = []
        ring_id = f'RING_{ring_id_counter:04d}'
        
        for cycle_num in range(num_cycles):
            amount = base_amount * (1 + 0.05 * cycle_num)
            amount_per_txn = amount / 5
            
            cycle_start = datetime.strptime(CONFIG["start_date"], "%Y-%m-%d") + timedelta(
                days=random.randint(0, 85),
                hours=random.choice([8, 9, 10, 14, 15, 16])
            )
            
            for i in range(5):
                src = participant_ids[i]
                dst = participant_ids[(i + 1) % 5]
                
                timestamp = cycle_start + timedelta(hours=i*1.5)
                
                ring_transactions.append({
                    'source_account': src,
                    'destination_account': dst,
                    'amount': round(amount_per_txn, 2),
                    'timestamp': timestamp.strftime('%Y-%m-%d %H:%M:%S'),
                    'ring_id': ring_id,
                    'is_fraud': 1,
                    'cycle_num': cycle_num
                })
        
        fraud_transactions.extend(ring_transactions)
        
        fraud_rings.append({
            'ring_id': ring_id,
            'ring_type': random.choice(['money_laundering', 'account_takeover', 'collusion', 'phishing']),
            'participants': participant_ids,
            'participant_count': 5,
            'transactions': len(ring_transactions),
            'total_amount': round(sum(t['amount'] for t in ring_transactions), 2),
            'pattern': 'cycle_5',
            'cycles': num_cycles
        })
        
        print(f"  • Medium ring {ring_id_counter}: {len(participant_ids)} participants → ${round(sum(t['amount'] for t in ring_transactions), 2):,.0f}")
        ring_id_counter += 1
    
    # Large rings (8 participants)
    for _ in range(CONFIG['large_rings']):
        participants = random.sample(accounts, 8)
        participant_ids = [acc['account_id'] for acc in participants]
        
        num_cycles = random.randint(10, 20)
        base_amount = random.uniform(200000, 350000)
        
        ring_transactions = []
        ring_id = f'RING_{ring_id_counter:04d}'
        
        for cycle_num in range(num_cycles):
            amount = base_amount * (1 + 0.05 * cycle_num)
            
            # Variable transactions per cycle (8-12)
            txn_count = random.randint(8, 12)
            amount_per_txn = amount / txn_count
            
            cycle_start = datetime.strptime(CONFIG["start_date"], "%Y-%m-%d") + timedelta(
                days=random.randint(0, 85),
                hours=random.choice([8, 9, 10, 14, 15, 16])
            )
            
            # Create connections between participants
            for i in range(txn_count):
                src_idx = i % 8
                dst_idx = (i + random.randint(1, 7)) % 8
                
                src = participant_ids[src_idx]
                dst = participant_ids[dst_idx]
                
                timestamp = cycle_start + timedelta(hours=i)
                
                ring_transactions.append({
                    'source_account': src,
                    'destination_account': dst,
                    'amount': round(amount_per_txn, 2),
                    'timestamp': timestamp.strftime('%Y-%m-%d %H:%M:%S'),
                    'ring_id': ring_id,
                    'is_fraud': 1,
                    'cycle_num': cycle_num
                })
        
        fraud_transactions.extend(ring_transactions)
        
        fraud_rings.append({
            'ring_id': ring_id,
            'ring_type': random.choice(['money_laundering', 'account_takeover', 'collusion', 'phishing']),
            'participants': participant_ids,
            'participant_count': 8,
            'transactions': len(ring_transactions),
            'total_amount': round(sum(t['amount'] for t in ring_transactions), 2),
            'pattern': 'complex_network',
            'cycles': num_cycles
        })
        
        print(f"  • Large ring {ring_id_counter}: {len(participant_ids)} participants → ${round(sum(t['amount'] for t in ring_transactions), 2):,.0f}")
        ring_id_counter += 1
    
    return fraud_rings, fraud_transactions

def generate_normal_transactions(accounts, merchants, count):
    """Generate normal (non-fraud) transactions"""
    print(f"Generating {count} normal transactions...")
    
    transactions = []
    start_date = datetime.strptime(CONFIG["start_date"], "%Y-%m-%d")
    end_date = datetime.strptime(CONFIG["end_date"], "%Y-%m-%d")
    
    # Get account IDs
    account_ids = [acc['account_id'] for acc in accounts]
    
    channels = ['online', 'mobile', 'atm', 'branch']
    channel_weights = [0.50, 0.35, 0.10, 0.05]
    
    currencies = ['VND', 'USD', 'EUR']
    currency_weights = [0.70, 0.20, 0.10]
    
    exchange_rates = {
        'VND_to_USD': 25000,
        'EUR_to_USD': 1.08,
        'GBP_to_USD': 1.27
    }
    
    for i in range(count):
        # Random date within range
        random_days = random.randint(0, (end_date - start_date).days)
        
        # Time pattern: 85% business hours, 15% other
        is_business_hour = random.random() < 0.85
        
        if is_business_hour:
            hour = random.choice(range(8, 18))
        else:
            hour = random.choice(range(24))
        
        timestamp = start_date + timedelta(days=random_days, hours=hour, minutes=random.randint(0, 59))
        
        # Amount (lognormal distribution approximation)
        amount = max(50, min(50000, random.lognormvariate(7, 0.5)))
        
        # Currency
        currency = random.choices(currencies, currency_weights)[0]
        
        # Convert to USD
        if currency == 'VND':
            amount_usd = amount / exchange_rates['VND_to_USD']
        elif currency == 'EUR':
            amount_usd = amount * exchange_rates['EUR_to_USD']
        else:
            amount_usd = amount
        
        # Random source and destination
        src = random.choice(account_ids)
        dst = random.choice(account_ids)
        
        # Ensure different
        while dst == src:
            dst = random.choice(account_ids)
        
        # Channel
        channel = random.choices(channels, channel_weights)[0]
        
        transactions.append({
            'transaction_id': f'TXN_{i+1:09d}',
            'source_account': src,
            'destination_account': dst,
            'amount_usd': round(amount_usd, 2),
            'original_amount': round(amount, 2),
            'original_currency': currency,
            'timestamp': timestamp.strftime('%Y-%m-%d %H:%M:%S'),
            'date': timestamp.strftime('%Y-%m-%d'),
            'hour': hour,
            'channel': channel,
            'transaction_type': 'p2p',
            'is_fraud': 0,
            'fraud_ring_id': None
        })
    
    return transactions

def save_accounts(accounts):
    """Save accounts to CSV"""
    filepath = "data/synthetic/raw/accounts.csv"
    with open(filepath, 'w', newline='', encoding='utf-8') as csvfile:
        fieldnames = accounts[0].keys()
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(accounts)
    print(f"Saved {len(accounts)} accounts to {filepath}")

def save_merchants(merchants):
    """Save merchants to CSV"""
    filepath = "data/synthetic/raw/merchants.csv"
    with open(filepath, 'w', newline='', encoding='utf-8') as csvfile:
        fieldnames = merchants[0].keys()
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(merchants)
    print(f"Saved {len(merchants)} merchants to {filepath}")

def save_transactions(transactions):
    """Save transactions to CSV"""
    filepath = "data/synthetic/raw/transactions.csv"
    
    # Define common fieldnames for all transactions
    fieldnames = [
        'transaction_id', 'source_account', 'destination_account', 'amount_usd',
        'original_amount', 'original_currency', 'timestamp', 'date', 'hour',
        'channel', 'transaction_type', 'is_fraud', 'fraud_ring_id'
    ]
    
    with open(filepath, 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        
        for txn in transactions:
            # Filter the transaction to only include the common fields
            filtered_txn = {key: txn.get(key, '') for key in fieldnames}
            writer.writerow(filtered_txn)
            
    print(f"Saved {len(transactions)} transactions to {filepath}")

def save_fraud_rings(fraud_rings):
    """Save fraud rings to JSON"""
    filepath = "data/synthetic/ground_truth/fraud_rings.json"
    
    metadata = {
        'rings': fraud_rings,
        'total_rings': len(fraud_rings),
        'total_fraud_transactions': sum(r['transactions'] for r in fraud_rings),
        'total_fraud_amount': sum(r['total_amount'] for r in fraud_rings)
    }
    
    with open(filepath, 'w', encoding='utf-8') as jsonfile:
        json.dump(metadata, jsonfile, indent=2)
    print(f"Saved fraud ring metadata to {filepath}")

def main():
    """Main execution"""
    print("="*70)
    print("🚀 FRAUD RING DETECTION - SYNTHETIC DATA GENERATION")
    print("="*70)
    print("For Academic Paper Submission")
    print("="*70)
    
    start_time = datetime.now()
    
    # Generate accounts
    accounts = generate_accounts()
    merchants = generate_merchants()
    
    # Generate fraud rings
    fraud_rings, fraud_transactions = generate_fraud_rings(accounts)
    
    # Generate normal transactions
    normal_txn_count = int(CONFIG['total_transactions'] * CONFIG['normal_transaction_ratio'])
    normal_transactions = generate_normal_transactions(accounts, merchants, normal_txn_count)
    
    # Combine all transactions and shuffle
    all_transactions = normal_transactions + fraud_transactions
    random.shuffle(all_transactions)
    
    # Add transaction IDs to fraud transactions
    for i, txn in enumerate(all_transactions):
        if 'transaction_id' not in txn:
            txn['transaction_id'] = f'TXN_{i+1:09d}'
    
    # Save data
    save_accounts(accounts)
    save_merchants(merchants)
    save_transactions(all_transactions)
    save_fraud_rings(fraud_rings)
    
    end_time = datetime.now()
    duration = (end_time - start_time).total_seconds()
    
    # Print summary
    print("\n" + "="*70)
    print("📊 GENERATION SUMMARY")
    print("="*70)
    print(f"Accounts:           {len(accounts):,}")
    print(f"Merchants:          {len(merchants):,}")
    print(f"Transactions:       {len(all_transactions):,}")
    print(f"Fraud Rings:        {len(fraud_rings)}")
    print(f"Fraud Transactions: {len(fraud_transactions):,}")
    fraud_ratio = len(fraud_transactions) / len(all_transactions) * 100
    print(f"Fraud Ratio:        {fraud_ratio:.2f}%")
    print("="*70)
    print(f"✓ GENERATION COMPLETE in {duration:.1f} seconds")
    print("="*70)

if __name__ == "__main__":
    main()